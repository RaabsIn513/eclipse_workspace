package midterm1;


import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.IOException;


 
public class MainDriver  {
		private static int ncard;
       public static PrintWriter pw;
      
       public static void main(String [] args)throws IOException{
             
              Scanner keyboard = new Scanner(System.in);
              System.out.println("Enter file location right hurr");
              String s = keyboard.nextLine();
              FileOutputStream output = new FileOutputStream(s);
              pw = new PrintWriter(output);
              
              System.out.println("Computer showing this devious hand:");
                            
              BlackJack b;
              b = new BlackJack();
              b.getCards();
              b.getCards();//how do we not show this
             
              //Go to blackjack to figure out 2 random cards from array located in Deck
              //Show 1 random card
              System.out.println("One card facing down");
             
              System.out.println("This is your hand:");
              b.getCards();
              b.getCards();
              //Go to blackjack to figure out 2 random cards from array located in Deck
              //Show both random cards
              System.out.println("Score so far:");
              //Go to blackjack to figure out values of each card, and add them together to show running total
              System.out.println("Do you want to hit? Press 1, but otherwise press 2");
              //User picks if they want to hit or stand
              //If they hit, repeat the process of getting a random card
              //If they stand, then blackjack declares a winner by who has the highest score below 21
              //We're not worrying about busting yet
             
       }
}
