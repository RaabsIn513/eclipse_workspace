package com.sai.menu;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.widget.AdapterView.AdapterContextMenuInfo;

public class ShowContextMenu extends ListActivity {
	

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setListAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.names)));

        registerForContextMenu(getListView());
    }
    
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
    	super.onCreateContextMenu(menu, v, menuInfo);
    	MenuInflater inflater = getMenuInflater();
    	inflater.inflate(R.menu.context_menu, menu);
    }
    
    public boolean onContextItemSelected(MenuItem item) {
    	AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
    	String[] names = getResources().getStringArray(R.array.names);
    	switch(item.getItemId()) {
    	case R.id.edit:
    		Toast.makeText(this, "You have chosen the " + getResources().getString(R.string.edit) + 
    				" context menu option for " + names[(int)info.id],
            		Toast.LENGTH_SHORT).show();
    		return true;
    	case R.id.save:
    		Toast.makeText(this, "You have chosen the " + getResources().getString(R.string.save) + 
    				" context menu option for " + names[(int)info.id],
            		Toast.LENGTH_SHORT).show();
    		return true;
    	case R.id.delete:
    		Toast.makeText(this, "You have chosen the " + getResources().getString(R.string.delete) + 
    				" context menu option for " + names[(int)info.id],
            		Toast.LENGTH_SHORT).show();
    		return true;
    	case R.id.view:
    		Toast.makeText(this, "You have chosen the " + getResources().getString(R.string.view) + 
    				" context menu option for " + names[(int)info.id],
            		Toast.LENGTH_SHORT).show();
    		return true;
    	default:
    		return super.onContextItemSelected(item);
    	}
    }
    
    	
}